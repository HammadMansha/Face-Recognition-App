import sys

version = sys.version
