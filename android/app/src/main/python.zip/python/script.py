def factorial(a):
    fact=1
    for i in range(1,a+1):
        fact*=1
    return  fact
number=55
text="Subscribe"
