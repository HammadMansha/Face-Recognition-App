def my_function():
    print("hello entered")
    return "Hello from Python!"

my_function()
